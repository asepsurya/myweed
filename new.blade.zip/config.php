<?php

return [
    'name' => 'Contoh',
    'thumbnail' => 'love.png',
    'sections' => [

     
    ],
];
